#pragma once

#define DISABLE_PERF_MEASUREMENT (1)
